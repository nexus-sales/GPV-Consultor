-- ============================================================
-- MIGRACIÓN 01 — CIMIENTO DE FECHAS (NO DESTRUCTIVA)
-- ============================================================
-- Objetivo: que TODAS las tablas tengan un updated_at REAL
-- (timestamptz, automático por trigger), que es la base sobre
-- la que funciona la detección de conflictos del sync.
--
-- SEGURIDAD: Esta migración NO borra ninguna columna ni dato.
-- Solo AÑADE columnas y triggers. Es 100% reversible.
-- Se puede ejecutar varias veces sin causar daño (idempotente).
--
-- CÓMO USAR:
--   1. Haz un backup en Supabase (Database > Backups) ANTES.
--   2. Pega este script COMPLETO en el SQL Editor de Supabase.
--   3. Ejecuta. Revisa que no haya errores rojos.
--   4. Ejecuta el bloque de VERIFICACIÓN del final.
-- ============================================================


-- ------------------------------------------------------------
-- PASO 1: Función única que actualiza updated_at en cada UPDATE
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- ------------------------------------------------------------
-- PASO 2: Asegurar que cada tabla tiene la columna updated_at
--         (timestamptz). Si ya existe, no hace nada.
-- ------------------------------------------------------------
ALTER TABLE "distributorsGPV"        ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
ALTER TABLE "candidatesGPV"          ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
ALTER TABLE "visitsGPV"              ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
ALTER TABLE "salesGPV"               ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
ALTER TABLE "commissionAgreementsGPV" ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();
-- leads ya tiene updated_at timestamptz nativo, pero por si acaso:
ALTER TABLE leads                    ADD COLUMN IF NOT EXISTS updated_at timestamptz DEFAULT now();


-- ------------------------------------------------------------
-- PASO 3: Rellenar updated_at de las filas existentes.
--         Usamos el valor más fiable disponible, en orden:
--         1) el "updatedAt" text antiguo (si tiene fecha válida)
--         2) el created_at timestamptz que Postgres ya rellenó
--         3) now() como último recurso
--
--         NOTA: NULLIF + el casting protegido evita que un
--         texto vacío o malformado rompa la migración.
-- ------------------------------------------------------------

-- DISTRIBUIDORES (no tenía "updatedAt", usamos created_at)
UPDATE "distributorsGPV"
SET updated_at = COALESCE(
  -- intentar parsear el "createdAt" text antiguo si parece fecha
  NULLIF("createdAt", '')::timestamptz,
  created_at,
  now()
)
WHERE updated_at IS NULL;

-- CANDIDATOS (sí tenía "updatedAt" text)
UPDATE "candidatesGPV"
SET updated_at = COALESCE(
  NULLIF("updatedAt", '')::timestamptz,
  NULLIF("createdAt", '')::timestamptz,
  created_at,
  now()
)
WHERE updated_at IS NULL;

-- VISITAS (no tenía "updatedAt")
UPDATE "visitsGPV"
SET updated_at = COALESCE(
  NULLIF("createdAt", '')::timestamptz,
  created_at,
  now()
)
WHERE updated_at IS NULL;

-- VENTAS (sí tenía "updatedAt" text)
UPDATE "salesGPV"
SET updated_at = COALESCE(
  NULLIF("updatedAt", '')::timestamptz,
  NULLIF("createdAt", '')::timestamptz,
  created_at,
  now()
)
WHERE updated_at IS NULL;

-- ACUERDOS DE COMISIONES (sí tenía "updatedAt" text)
UPDATE "commissionAgreementsGPV"
SET updated_at = COALESCE(
  NULLIF("updatedAt", '')::timestamptz,
  NULLIF("createdAt", '')::timestamptz,
  created_at,
  now()
)
WHERE updated_at IS NULL;


-- ------------------------------------------------------------
-- PASO 3-bis: Si algún "updatedAt" text tenía un formato raro
-- que el casting no pudo convertir, el UPDATE anterior habría
-- fallado en esa fila. Para máxima seguridad ante datos sucios,
-- este bloque alternativo captura errores fila a fila.
-- (Solo se necesita si el PASO 3 da error de casting. Si el
-- PASO 3 funcionó sin errores, puedes ignorar este bloque.)
-- ------------------------------------------------------------
-- Versión defensiva: marca como now() cualquier fila que aún
-- tenga updated_at NULL tras el intento anterior.
UPDATE "distributorsGPV"        SET updated_at = now() WHERE updated_at IS NULL;
UPDATE "candidatesGPV"          SET updated_at = now() WHERE updated_at IS NULL;
UPDATE "visitsGPV"              SET updated_at = now() WHERE updated_at IS NULL;
UPDATE "salesGPV"               SET updated_at = now() WHERE updated_at IS NULL;
UPDATE "commissionAgreementsGPV" SET updated_at = now() WHERE updated_at IS NULL;


-- ------------------------------------------------------------
-- PASO 4: Crear los triggers que mantienen updated_at al día.
--         A partir de ahora, cada UPDATE actualiza la fecha solo.
--         DROP IF EXISTS primero para que sea re-ejecutable.
-- ------------------------------------------------------------
DROP TRIGGER IF EXISTS trg_updated_at ON "distributorsGPV";
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON "distributorsGPV"
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_updated_at ON "candidatesGPV";
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON "candidatesGPV"
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_updated_at ON "visitsGPV";
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON "visitsGPV"
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_updated_at ON "salesGPV";
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON "salesGPV"
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_updated_at ON "commissionAgreementsGPV";
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON "commissionAgreementsGPV"
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_updated_at ON leads;
CREATE TRIGGER trg_updated_at BEFORE UPDATE ON leads
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


-- ============================================================
-- VERIFICACIÓN — ejecuta esto DESPUÉS para confirmar que fue bien
-- ============================================================
-- Debe devolver 0 filas con updated_at NULL en todas las tablas:
--
--   SELECT 'distributorsGPV' AS tabla, count(*) AS sin_fecha
--   FROM "distributorsGPV" WHERE updated_at IS NULL
--   UNION ALL SELECT 'candidatesGPV', count(*) FROM "candidatesGPV" WHERE updated_at IS NULL
--   UNION ALL SELECT 'visitsGPV', count(*) FROM "visitsGPV" WHERE updated_at IS NULL
--   UNION ALL SELECT 'salesGPV', count(*) FROM "salesGPV" WHERE updated_at IS NULL
--   UNION ALL SELECT 'commissionAgreementsGPV', count(*) FROM "commissionAgreementsGPV" WHERE updated_at IS NULL
--   UNION ALL SELECT 'leads', count(*) FROM leads WHERE updated_at IS NULL;
--
-- Y para probar que el trigger funciona (cambia un distribuidor y
-- mira si updated_at cambia solo):
--
--   UPDATE "distributorsGPV" SET notes = notes WHERE id = (SELECT id FROM "distributorsGPV" LIMIT 1);
--   SELECT id, updated_at FROM "distributorsGPV" ORDER BY updated_at DESC LIMIT 1;
-- ============================================================

-- NOTA IMPORTANTE sobre las columnas viejas:
-- Esta migración NO toca "createdAt" ni "updatedAt" (text).
-- Siguen ahí, intactas, con tus datos. La app las sigue usando.
-- Las eliminaremos en una migración POSTERIOR, solo cuando el
-- código ya esté leyendo y escribiendo created_at/updated_at.
-- Así nunca hay un momento en que la app se rompa.
