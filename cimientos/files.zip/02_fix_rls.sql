-- ============================================================
-- MIGRACIÓN 02 — CERRAR LA RLS ABIERTA (SEGURIDAD)
-- ============================================================
-- Problema: salesGPV y backofficeContactsGPV tienen políticas
-- USING (true) WITH CHECK (true), lo que permite a CUALQUIER
-- usuario autenticado leer y modificar las ventas y contactos
-- de TODO el equipo. Esto anula el control de roles del frontend.
--
-- Esta migración reemplaza esas políticas por uno basado en rol.
--
-- ⚠️ ANTES DE EJECUTAR — LEE ESTO:
-- Esta migración asume que existe una columna que indica el
-- "dueño" de cada registro (quién lo creó). Si tus tablas NO
-- tienen esa columna, la añadimos primero (PASO 0).
--
-- Decide tu política de negocio:
--   OPCIÓN A (recomendada para empezar): admin/manager ven todo,
--            y el resto también ve todo PERO solo puede MODIFICAR
--            lo suyo. Es el cambio mínimo que no rompe la vista
--            de equipo actual pero cierra la escritura.
--   OPCIÓN B (más estricta): cada commercial solo VE lo suyo.
--            Puede romper pantallas que muestran datos de equipo.
--
-- Este script implementa la OPCIÓN A (más segura de adoptar).
-- ============================================================


-- ------------------------------------------------------------
-- PASO 0: Asegurar columna de propiedad (quién creó el registro)
--         Si ya existe, no hace nada.
-- ------------------------------------------------------------
ALTER TABLE "salesGPV"
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);

-- Rellenar created_by de filas existentes con NULL es aceptable:
-- las filas sin dueño solo serán visibles/editables por admin/manager.


-- ------------------------------------------------------------
-- PASO 1: VENTAS — reemplazar política abierta
-- ------------------------------------------------------------

-- Eliminar TODAS las políticas viejas de salesGPV (limpieza)
DROP POLICY IF EXISTS "Auth read salesGPV"   ON "salesGPV";
DROP POLICY IF EXISTS "Auth insert salesGPV" ON "salesGPV";
DROP POLICY IF EXISTS "Auth update salesGPV" ON "salesGPV";
DROP POLICY IF EXISTS "Auth delete salesGPV" ON "salesGPV";
DROP POLICY IF EXISTS "open_access"          ON "salesGPV";

-- LECTURA: todos los autenticados pueden leer (mantiene la vista de equipo)
CREATE POLICY "sales_read" ON "salesGPV"
  FOR SELECT TO authenticated
  USING (true);

-- INSERCIÓN: cualquier autenticado puede crear, pero se registra como suyo
CREATE POLICY "sales_insert" ON "salesGPV"
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- ACTUALIZACIÓN: solo admin/manager o el dueño del registro
CREATE POLICY "sales_update" ON "salesGPV"
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "user_profilesGPV" p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'manager')
    )
    OR created_by = auth.uid()
  );

-- BORRADO: solo admin/manager
CREATE POLICY "sales_delete" ON "salesGPV"
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "user_profilesGPV" p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'manager')
    )
  );


-- ------------------------------------------------------------
-- PASO 2: CONTACTOS DE BACKOFFICE — mismo patrón
-- ------------------------------------------------------------
-- NOTA: ajusta el nombre de tabla si es distinto en tu BD.
-- Verifica primero con:
--   SELECT tablename FROM pg_tables WHERE tablename ILIKE '%backoffice%';

ALTER TABLE "backofficeContactsGPV"
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);

DROP POLICY IF EXISTS "Auth read backofficeContactsGPV"   ON "backofficeContactsGPV";
DROP POLICY IF EXISTS "Auth insert backofficeContactsGPV" ON "backofficeContactsGPV";
DROP POLICY IF EXISTS "Auth update backofficeContactsGPV" ON "backofficeContactsGPV";
DROP POLICY IF EXISTS "Auth delete backofficeContactsGPV" ON "backofficeContactsGPV";
DROP POLICY IF EXISTS "open_access"                       ON "backofficeContactsGPV";

CREATE POLICY "backoffice_read" ON "backofficeContactsGPV"
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "backoffice_insert" ON "backofficeContactsGPV"
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "backoffice_update" ON "backofficeContactsGPV"
  FOR UPDATE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "user_profilesGPV" p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'manager')
    )
    OR created_by = auth.uid()
  );

CREATE POLICY "backoffice_delete" ON "backofficeContactsGPV"
  FOR DELETE TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "user_profilesGPV" p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'manager')
    )
  );


-- ============================================================
-- VERIFICACIÓN
-- ============================================================
-- Ver las políticas activas de ambas tablas:
--
--   SELECT tablename, policyname, cmd
--   FROM pg_policies
--   WHERE tablename IN ('salesGPV', 'backofficeContactsGPV')
--   ORDER BY tablename, cmd;
--
-- Debe mostrar 4 políticas por tabla (read/insert/update/delete),
-- y NINGUNA con "true" en la parte de UPDATE/DELETE.
-- ============================================================
